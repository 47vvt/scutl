# scutl
customizable and minimalist app launcher for students
